IGNORE_HEAD_CHANGES = True
ADD_STYLE = True
STYLE_STR = "<style>span.diff_insert {background-color: #a0ffa0;} span.diff_delete {background-color: red;}</style>"
CUSTOM_STYLE_STR = ""
WHITELISTED_TAGS = ["img", "input"]
BLACKLISTED_TAGS = ["head", "script", "style", "noscript"]

EXCLUDE_STRINGS_A = []
EXCLUDE_STRINGS_B = []
